export 'generate_p_d_f_from_h_t_m_l.dart' show generatePDFFromHTML;
export 'build_report_h_t_m_l.dart' show buildReportHTML;
export 'build_report_h_t_m_l_semestre1.dart' show buildReportHTMLSemestre1;
export 'build_personalidad_h_t_m_l.dart' show buildPersonalidadHTML;
